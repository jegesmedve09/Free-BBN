#ifndef SOUND_H
#define SOUND_H

void sound_init(void);
void PlaySound(const char* file_path);
void PlaySound_old(const char* file_path);

#endif
