#ifndef SPLASH_H
#define SPLASH_H

void splash_show(void);

#endif
