#ifndef GFX_H
#define GFX_H
#include <gsKit.h>

extern GSGLOBAL *gsGlobal;

void gfx_init(void);
void gfx_clear(u64 color);

#endif
